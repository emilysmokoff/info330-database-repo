CREATE DATABASE  IF NOT EXISTS `free_people` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `free_people`;
-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: free_people
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `material`
--

DROP TABLE IF EXISTS `material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material`
--

LOCK TABLES `material` WRITE;
/*!40000 ALTER TABLE `material` DISABLE KEYS */;
INSERT INTO `material` VALUES (1);
/*!40000 ALTER TABLE `material` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `material-material_item`
--

DROP TABLE IF EXISTS `material-material_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material-material_item` (
  `materialId` int NOT NULL,
  `materialItemId` int NOT NULL,
  PRIMARY KEY (`materialId`,`materialItemId`),
  KEY `fromMaterialMaterialItemToMaterialItem_idx` (`materialItemId`),
  CONSTRAINT `fromMaterialMaterialItemToMaterial` FOREIGN KEY (`materialId`) REFERENCES `material` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fromMaterialMaterialItemToMaterialItem` FOREIGN KEY (`materialItemId`) REFERENCES `material_item` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material-material_item`
--

LOCK TABLES `material-material_item` WRITE;
/*!40000 ALTER TABLE `material-material_item` DISABLE KEYS */;
INSERT INTO `material-material_item` VALUES (1,1);
/*!40000 ALTER TABLE `material-material_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `material_item`
--

DROP TABLE IF EXISTS `material_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `percent` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_item`
--

LOCK TABLES `material_item` WRITE;
/*!40000 ALTER TABLE `material_item` DISABLE KEYS */;
INSERT INTO `material_item` VALUES (1,'Cotton',100),(2,'Wool',100),(5,'Nylon',10),(6,'Silk',5);
/*!40000 ALTER TABLE `material_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_of_review`
--

DROP TABLE IF EXISTS `page_of_review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `page_of_review` (
  `id` int NOT NULL AUTO_INCREMENT,
  `personalReviewId` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fromPageOfReviewToPersonalReview_idx` (`personalReviewId`),
  CONSTRAINT `fromPageOfReviewToPersonalReview` FOREIGN KEY (`personalReviewId`) REFERENCES `personal_review` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_of_review`
--

LOCK TABLES `page_of_review` WRITE;
/*!40000 ALTER TABLE `page_of_review` DISABLE KEYS */;
INSERT INTO `page_of_review` VALUES (1,1),(2,2),(3,3);
/*!40000 ALTER TABLE `page_of_review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_review`
--

DROP TABLE IF EXISTS `personal_review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_review` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `location` varchar(100) DEFAULT NULL,
  `age` varchar(100) DEFAULT NULL,
  `bodyType` varchar(100) DEFAULT NULL,
  `height` varchar(100) DEFAULT NULL,
  `photo` varchar(100) DEFAULT NULL,
  `star` float NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `fit` varchar(100) NOT NULL,
  `purchaseSize` int NOT NULL,
  `usualSize` int NOT NULL,
  `recommendStatus` tinyint(1) NOT NULL,
  `date` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_review`
--

LOCK TABLES `personal_review` WRITE;
/*!40000 ALTER TABLE `personal_review` DISABLE KEYS */;
INSERT INTO `personal_review` VALUES (1,'emilys','Seattle','21','athletic','5 foot 6 inch','photo.png',5,'so comfy','best dress ever','usual to size',6,6,1,'June 6th'),(2,'smokoff','Bellevue','23','athletic','5 foot 4 inch','photo.png',4,'very soft','lovely shirt','usual to size',8,8,1,'May 6th'),(3,'hello','Tacoma','25','athletic','5 foot 8 inch','photo.png',3,'very soft','lovely sweater','usual to size',4,4,1,'March 6th'),(6,'favoriteShopper','Boston','30','Curvy','5 foot 5 inch','reviewIMG.jpg',4.8,'New Favorite','I wear this everyday','Runs Big',6,8,1,'September 21st'),(7,'favoriteShopper','Boston','30','Curvy','5 foot 5 inch','reviewIMG.jpg',4.8,'New Favorite','I wear this everyday','Runs Big',6,8,1,'September 21st'),(8,'Backend Shopper','Online','50','Skinny','5 foot 3 inch','backendIMG.jpg',5,'The Best','You\'ll never wear anything else','Runs Big',8,10,1,'September 4th'),(9,'Backend Shopper','Online','50','Skinny','5 foot 3 inch','backendIMG.jpg',5,'The Best','You\'ll never wear anything else','Runs Big',8,10,1,'September 4th');
/*!40000 ALTER TABLE `personal_review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `id` int NOT NULL AUTO_INCREMENT,
  `productInformationTitle` varchar(100) NOT NULL,
  `productReviewId` int NOT NULL,
  `productDetailId` int NOT NULL,
  `productPhotoId` int NOT NULL,
  `materialId` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fromProductToProductInformation_idx` (`productInformationTitle`),
  KEY `fromProductToProductReview_idx` (`productReviewId`),
  KEY `fromProductToProductDetail_idx` (`productDetailId`),
  KEY `fromProductToProductPhoto_idx` (`productPhotoId`),
  KEY `fromProductToMaterial_idx` (`materialId`),
  CONSTRAINT `fromProductToMaterial` FOREIGN KEY (`materialId`) REFERENCES `material` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fromProductToProductDetail` FOREIGN KEY (`productDetailId`) REFERENCES `product_detail` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fromProductToProductInformation` FOREIGN KEY (`productInformationTitle`) REFERENCES `product_information` (`title`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fromProductToProductPhoto` FOREIGN KEY (`productPhotoId`) REFERENCES `product_photo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fromProductToProductReview` FOREIGN KEY (`productReviewId`) REFERENCES `product_review` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product-product_acquisition`
--

DROP TABLE IF EXISTS `product-product_acquisition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product-product_acquisition` (
  `productId` int NOT NULL,
  `productAcquisitionId` int NOT NULL,
  PRIMARY KEY (`productId`,`productAcquisitionId`),
  KEY `fromProductProductAcquisitionToProductAcquisition_idx` (`productAcquisitionId`),
  CONSTRAINT `fromProductProductAcquisitionToProduct` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fromProductProductAcquisitionToProductAcquisition` FOREIGN KEY (`productAcquisitionId`) REFERENCES `product_acquisition` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product-product_acquisition`
--

LOCK TABLES `product-product_acquisition` WRITE;
/*!40000 ALTER TABLE `product-product_acquisition` DISABLE KEYS */;
/*!40000 ALTER TABLE `product-product_acquisition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product-store_availability`
--

DROP TABLE IF EXISTS `product-store_availability`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product-store_availability` (
  `productId` int NOT NULL,
  `storeAvailabilityId` int NOT NULL,
  PRIMARY KEY (`productId`,`storeAvailabilityId`),
  KEY `fromProductStoreAvailabilityToStoreAvailability_idx` (`storeAvailabilityId`),
  CONSTRAINT `fromProductStoreAvailabilityToProduct` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fromProductStoreAvailabilityToStoreAvailability` FOREIGN KEY (`storeAvailabilityId`) REFERENCES `store_availability` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product-store_availability`
--

LOCK TABLES `product-store_availability` WRITE;
/*!40000 ALTER TABLE `product-store_availability` DISABLE KEYS */;
/*!40000 ALTER TABLE `product-store_availability` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_acquisition`
--

DROP TABLE IF EXISTS `product_acquisition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_acquisition` (
  `id` int NOT NULL AUTO_INCREMENT,
  `shippingTitle` varchar(100) NOT NULL,
  `storePickupTitle` varchar(100) NOT NULL,
  `returnTitle` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fromProductAcquisitionToShipping_idx` (`shippingTitle`),
  KEY `fromProductAcquisitionToStorePickup_idx` (`storePickupTitle`),
  KEY `fromProductAcquisitionToReturn_idx` (`returnTitle`),
  CONSTRAINT `fromProductAcquisitionToReturn` FOREIGN KEY (`returnTitle`) REFERENCES `return` (`title`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fromProductAcquisitionToShipping` FOREIGN KEY (`shippingTitle`) REFERENCES `shipping` (`title`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fromProductAcquisitionToStorePickup` FOREIGN KEY (`storePickupTitle`) REFERENCES `store_pickup` (`title`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_acquisition`
--

LOCK TABLES `product_acquisition` WRITE;
/*!40000 ALTER TABLE `product_acquisition` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_acquisition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_detail`
--

DROP TABLE IF EXISTS `product_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_detail` (
  `id` int NOT NULL AUTO_INCREMENT,
  `styleNumber` int NOT NULL,
  `colorCode` int NOT NULL,
  `description` varchar(200) NOT NULL,
  `care` varchar(100) NOT NULL,
  `origin` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_detail`
--

LOCK TABLES `product_detail` WRITE;
/*!40000 ALTER TABLE `product_detail` DISABLE KEYS */;
INSERT INTO `product_detail` VALUES (1,987,13,'description','Hand-Wash','US'),(2,587,111,'description','Wash Cold','US'),(4,234,12,'description','Cold Wash','Canada'),(5,234,12,'description','Cold Wash','Canada');
/*!40000 ALTER TABLE `product_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_information`
--

DROP TABLE IF EXISTS `product_information`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_information` (
  `title` varchar(100) NOT NULL,
  `popularity` tinyint(1) NOT NULL,
  `reviewCount` int NOT NULL,
  `starRate` float NOT NULL,
  `price` float NOT NULL,
  `alternatePrice` json NOT NULL,
  `size` json NOT NULL,
  `color` json NOT NULL,
  PRIMARY KEY (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_information`
--

LOCK TABLES `product_information` WRITE;
/*!40000 ALTER TABLE `product_information` DISABLE KEYS */;
INSERT INTO `product_information` VALUES ('Nice Sweater',0,90,4.5,80,'[{\"Price\": \"20\", \"Installments\": \"4\"}]','[{\"Size\": \"XS\"}, {\"Size\": \"S\"}, {\"Size\": \"M\"}, {\"Size\": \"L\"}]','[{\"id\": \"009\", \"Color\": \"Yellow\"}, {\"id\": \"014\", \"Color\": \"Black\"}, {\"id\": \"012\", \"Color\": \"Pink\"}]'),('The Doors Dress',1,1300,4.9,32.68,'[{\"Price\": \"8.17\", \"Installments\": \"4\"}]','[{\"Size\": \"XS\"}, {\"Size\": \"L\"}]','[{\"id\": \"014\", \"Color\": \"Black\"}, {\"id\": \"012\", \"Color\": \"Pink\"}]');
/*!40000 ALTER TABLE `product_information` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_photo`
--

DROP TABLE IF EXISTS `product_photo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_photo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cover` varchar(100) NOT NULL,
  `likeCount` int NOT NULL,
  `selectedImage` varchar(100) NOT NULL,
  `accessoryImage` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_photo`
--

LOCK TABLES `product_photo` WRITE;
/*!40000 ALTER TABLE `product_photo` DISABLE KEYS */;
INSERT INTO `product_photo` VALUES (2,'cover2.png',2000,'selectedImage2.png','accessoryImage2.png'),(3,'cover3.png',300,'selectedImage3.png','accessoryImage3.png');
/*!40000 ALTER TABLE `product_photo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_review`
--

DROP TABLE IF EXISTS `product_review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_review` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rating` float NOT NULL,
  `reviewCount` int NOT NULL,
  `percentRecommended` int NOT NULL,
  `fitToSize` varchar(100) NOT NULL,
  `pageOfReviewId` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fromProductReviewToPageOfReview_idx` (`pageOfReviewId`),
  CONSTRAINT `fromProductReviewToPageOfReview` FOREIGN KEY (`pageOfReviewId`) REFERENCES `page_of_review` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_review`
--

LOCK TABLES `product_review` WRITE;
/*!40000 ALTER TABLE `product_review` DISABLE KEYS */;
INSERT INTO `product_review` VALUES (1,4.7,1300,95,'Runs Big',1);
/*!40000 ALTER TABLE `product_review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `return`
--

DROP TABLE IF EXISTS `return`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `return` (
  `title` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `returnPolicy` json NOT NULL,
  PRIMARY KEY (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `return`
--

LOCK TABLES `return` WRITE;
/*!40000 ALTER TABLE `return` DISABLE KEYS */;
INSERT INTO `return` VALUES ('International Returns','Mail items back with paid label','[{\"Return Method\": \"Original form of payment\", \"Return Policy\": \"Within 15 days of delivery\"}, {\"Return Method\": \"e-gift card\", \"Return Policy\": \"After 15 days of delivery\"}]'),('US Returns','Mail items back with paid label','[{\"Return Method\": \"Original form of payment\", \"Return Policy\": \"Within 10 days of delivery\"}, {\"Return Method\": \"e-gift card\", \"Return Policy\": \"After 10 days of delivery\"}]');
/*!40000 ALTER TABLE `return` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipping`
--

DROP TABLE IF EXISTS `shipping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipping` (
  `title` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `notice` varchar(100) NOT NULL,
  `shippingMethod` json NOT NULL,
  PRIMARY KEY (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipping`
--

LOCK TABLES `shipping` WRITE;
/*!40000 ALTER TABLE `shipping` DISABLE KEYS */;
INSERT INTO `shipping` VALUES ('International Shipping','Below are estimates','*Orders can be expedited.','[{\"Price\": \"10.00\", \"Method\": \"Standard\", \"Estimated Delivery\": \"10-12 days\"}, {\"Price\": \"20.00\", \"Method\": \"Express\", \"Estimated Delivery\": \"8-10 days\"}]'),('US Shipping','Below are estimates','*Orders cannot be expedited.','[{\"Price\": \"Free\", \"Method\": \"Standard\", \"Estimated Delivery\": \"10-12 days\"}, {\"Price\": \"10.00\", \"Method\": \"Express\", \"Estimated Delivery\": \"5-8 days\"}]');
/*!40000 ALTER TABLE `shipping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `store_availability`
--

DROP TABLE IF EXISTS `store_availability`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `store_availability` (
  `id` int NOT NULL AUTO_INCREMENT,
  `city` varchar(100) NOT NULL,
  `storeAddress` varchar(100) NOT NULL,
  `availability` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store_availability`
--

LOCK TABLES `store_availability` WRITE;
/*!40000 ALTER TABLE `store_availability` DISABLE KEYS */;
INSERT INTO `store_availability` VALUES (2,'Bellevue','Brooklyn ave',1);
/*!40000 ALTER TABLE `store_availability` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `store_pickup`
--

DROP TABLE IF EXISTS `store_pickup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `store_pickup` (
  `title` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `notice` varchar(100) NOT NULL,
  PRIMARY KEY (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store_pickup`
--

LOCK TABLES `store_pickup` WRITE;
/*!40000 ALTER TABLE `store_pickup` DISABLE KEYS */;
INSERT INTO `store_pickup` VALUES ('Curbside Pickup','Most items available in 24 hours','Item is available'),('In-Store Pickup','Most items available in 48 hours','Item is available'),('No Pickup Available','Most items are available through shipping','Item is not available');
/*!40000 ALTER TABLE `store_pickup` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-02  2:36:46
