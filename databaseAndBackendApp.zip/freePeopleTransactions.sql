-- ********************
-- *  Create Queries  *  
-- ********************

-- addOrUpdatePersonalReview
-- adds a new row into the personal review table at the next available index
INSERT INTO `personal_review` (`id`, `username`, `location`, `age`, `bodyType`, `height`, `photo`, `star`, `title`, `description`, `fit`, 
`purchaseSize`, `usualSize`, `recommendStatus`, `date`) VALUES
(null, 'favoriteShopper', 'Boston', '30', 'Curvy', '5 foot 5 inch', 'reviewIMG.jpg', '4.8', 'New Favorite', 'I wear this everyday', 'Runs Big',
 '6', '8', '1', 'September 21st')
 ON DUPLICATE KEY UPDATE username=values(username), location=values(location), age=values(age), bodyType=values(bodyType), height=values(height), photo=values(photo),
 star=values(star), title=values(title), `description`=values(`description`), fit=values(fit), purchaseSize=values(purchaseSize), usualSize=values(usualSize),
 recommendStatus=values(recommendStatus), `date`=values(`date`);
 
SELECT * FROM `personal_review`;

-- addOrUpdateProductReview
-- updates the product review row with id 1 with a new rating and review count
INSERT INTO `product_review` (`id`, `rating`, `reviewCount`, `percentRecommended`, `fitToSize`, `pageOfReviewId`) VALUES
('1', '4.9', '1100', '97', 'Usual Fit', '1')
ON DUPLICATE KEY UPDATE rating=values(rating), reviewCount=values(reviewCount), percentRecommended=values(percentRecommended), fitToSize=values(fitToSize);

SELECT * FROM `product_review`;

-- addOrUpdateProductInformation
-- update by taking size small out of the json column of sizes for the doors dress, as well as making the review count 1100, and making the star rate 4.9
INSERT INTO `product_information` (`title`, `popularity`, `reviewCount`, `starRate`, `price`, `alternatePrice`, `size`, `color`) VALUES
('The Doors Dress', '1', '1100', '4.9', '32.68', '[{"Installments": "4", "Price": "8.17"}]', '[{"Size": "XS"}, {"Size": "M"}, {"Size": "L"}]',
'[{"id": "010", "Color": "White"}, {"id": "013", "Color": "Blue"}, {"id": "012", "Color": "Pink"}]')
ON DUPLICATE KEY UPDATE popularity=values(popularity), reviewCount=values(reviewCount), starRate=values(starRate), price=values(price),
alternatePrice=values(alternatePrice), size=values(size), color=values(color);

SELECT * FROM `product_information`;

-- addOrUpdateMaterialItem
-- adding a row to the material item table that is a nylon material to the next available id
INSERT INTO `material_item` (`id`, `name`, `percent`) VALUES
(null, 'Nylon', '10')
ON DUPLICATE KEY UPDATE `name`=values(`name`), percent=values(percent);

SELECT * FROM `material_item`;

-- addOrUpdateProductDetail
-- updating the product detail table row with id of 1 to have a color code of 013
INSERT INTO `product_detail` (`id`, `styleNumber`, `colorCode`, `description`, `care`, `origin`) VALUES
('1', '0987', '013', 'description', 'Hand-Wash', 'US')
ON DUPLICATE KEY UPDATE styleNumber=values(styleNumber), colorCode=values(colorCode), `description`=values(`description`), care=values(care), origin=values(origin);

SELECT * FROM `product_detail`;

-- addOrUpdateShipping
-- updating the US shipping json column of shipping method, by changing the amount of days for shipping to 10-12 for standard and 5-8 for express
INSERT INTO `shipping` (`title`, `description`, `notice`, `shippingMethod`) VALUES
('US Shipping', 'Below are estimates', '*Orders cannot be expedited.', 
'[{"Method": "Standard", "Estimated Delivery": "10-12 days", "Price": "Free"}, 
{"Method": "Express", "Estimated Delivery": "5-8 days", "Price": "10.00"}]')
ON DUPLICATE KEY UPDATE `description`=values(`description`), notice=values(notice), shippingMethod=values(shippingMethod);

SELECT * FROM `shipping`;

-- addOrUpdateStorePickup
-- updates the notice of the in store pickup row of the store pickup table to item not available
INSERT INTO `store_pickup` (`title`, `description`, `notice`) VALUES
('In-Store Pickup', 'Most items available in 24 hours', 'Item is not available')
ON DUPLICATE KEY UPDATE `description`=values(`description`), notice=values(notice);

SELECT * FROM `store_pickup`;

-- addOrUpdateReturn
-- updates the return policy json column of US return row to within 10 days of delivery instead of 30
INSERT INTO `return` (`title`, `description`, `returnPolicy`) VALUES 
('US Returns', 'Mail items back with paid label', 
'[{"Return Policy": "Within 10 days of delivery", "Return Method": "Original form of payment"}, 
{"Return Policy": "After 10 days of delivery", "Return Method": "e-gift card"}]')
ON DUPLICATE KEY UPDATE `description`=values(`description`), returnPolicy=values(returnPolicy);

SELECT * FROM `return`;


-- ********************
-- * Retrieve Queries *
-- ********************

-- getProductAcquisition
-- returns the table including everything encompassed by product acquisition, and only the row where the product acquisition id is 1
SELECT `return`.title AS "Return Option for Area", `return`.description AS "Return Info", `return`.returnPolicy AS "Return Policy",
`store_pickup`.title AS "Store Pickup Option", `store_pickup`.description AS "Store Pickup Description", `store_pickup`.notice AS "Item Availability",
`shipping`.title AS "Shipping Option for Area", `shipping`.description AS "Shipping Information", `shipping`.notice AS "Shipping Notice",
`shipping`.shippingMethod AS "Shipping Methods"
FROM `return`
JOIN `product_acquisition` ON `product_acquisition`.returnTitle = `return`.title
JOIN `store_pickup` ON `store_pickup`.title = `product_acquisition`.storePickupTitle
JOIN `shipping` ON `shipping`.title = `product_acquisition`.shippingTitle
WHERE shippingTitle = "US Shipping";

-- getProductReview
-- left outer join
-- this retrieve query puts together all the information that is shown in the review page, including a personal review's information
SELECT `product_review`.rating AS "Overall Rating", `product_review`.reviewCount AS "Reviews", 
`product_review`.percentRecommended AS "Customer Percent Recommended", `product_review`.fitToSize AS "General Fit",
`personal_review`.username AS "Username", `personal_review`.location AS "Location", `personal_review`.age AS "Age",
`personal_review`.bodyType AS "Body Type", `personal_review`.height AS "Height", `personal_review`.photo AS "Image Link",
`personal_review`.date AS "Date Reviewed", `personal_review`.star AS "Personal Star Review", `personal_review`.title AS "Title",
`personal_review`.description AS "Description", `personal_review`.fit AS "Product Fit", `personal_review`.purchaseSize AS "Size Purchased",
`personal_review`.usualSize AS "Usual Size", `personal_review`.recommendStatus AS "Recommendation"
FROM `product_review`
LEFT OUTER JOIN `page_of_review` ON `page_of_review`.id = `product_review`.pageOfReviewId
LEFT OUTER JOIN `personal_review` ON `personal_review`.id = `page_of_review`.personalReviewId
WHERE `product_review`.id = 1;

-- ********************
-- *  Update Queries  *
-- ********************

-- updateStoreAvailability
-- updates the availability of an item from 0 (false) to 1 (true) when the city of the store is Seattle
SELECT * FROM `store_availability`;
UPDATE `store_availability` SET availability = 1 WHERE city = "Seattle";
SELECT * FROM `store_availability`;

-- updateProductPhoto
-- updates the like count of the product photos where the id of the photos is one
SELECT * FROM `product_photo`;
UPDATE `product_photo` SET likeCount = 1500 WHERE id = 1;
SELECT * FROM `product_photo`;

-- ********************
-- *  Delete Queries  *
-- ********************

-- deleteProductAcquisition
-- deletes the row of the product acquisition when the shipping title is US Shipping
SELECT * FROM `product_acquisition`;
DELETE FROM `product_acquisition` WHERE shippingTitle = "US Shipping";
SELECT * FROM `product_acquisition`;

-- deleteMaterial
-- deletes the row from the material table where the id is one
SELECT * FROM `material`;
DELETE FROM `material` WHERE id = 1;
SELECT * FROM `material`;

-- deleteProductReview
-- deletes the rows of product review where the percent recommended by customers is 80 percent or lower
SELECT * FROM `product_review`;
DELETE FROM `product_review` WHERE percentRecommended < 81;
SELECT * FROM `product_review`;

-- deleteStoreAvailability
-- deletes the rows of the store availability table where the product is in the city of bellevue
SELECT * FROM `store_availability`;
DELETE FROM `store_availability` WHERE city = "Bellevue";
SELECT * FROM `store_availability`;

-- deleteProductInformation
-- deletes the row from the product information table where the title is Nice Sweater
SELECT * FROM `product_information`;
DELETE FROM `product_information` WHERE title = "Nice Sweater";
SELECT * FROM `product_information`;

-- deleteProductDetail
-- deletes the row from the product detail table where the id is one
SELECT * FROM `product_detail`;
DELETE FROM `product_detail` WHERE id = 1;
SELECT * FROM `product_detail`;

-- deleteProductPhoto
-- deletes the row from the product photo table where the id is two
SELECT * FROM `product_photo`;
DELETE FROM `product_photo` WHERE id = 2;
SELECT * FROM `product_photo`;