var express = require('express');
var router = express.Router();
var db = require('../db')

router.get('/', function (req, res, next) {
  res.send(`Yes I am working in my app!`);
});

router.get('/showTables', (req, res, next) => {
  try {
    let query = "show tables;"
    db.executeQueryAsPromise(query, null)
      .then((queryResults) => {
        if (queryResults.length == 0) {
          queryResults = "No results found"
        }
        res.send(queryResults)
      }).catch((err) => { next(err) })
  }
  catch (err) { next(err) }
})

//************************************ */
//************CREATE ROUTES*********** */
//************************************ */

router.post("/addOrUpdatePersonalReview", function (req, res, next) {
  let { inputs } = req.body;
  let issue = null
  const validatedInputs = validateAndFormatInputs(inputs)
  if (validatedInputs.inputsAreValid) {
    let query = "\
      INSERT INTO `personal_review` (`id`, `username`, `location`, `age`, `bodyType`, `height`, `photo`, `star`, `title`, `description`, `fit`, \
      `purchaseSize`, `usualSize`, `recommendStatus`, `date`) VALUES \
      (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) \
      ON DUPLICATE KEY UPDATE username=values(username), location=values(location), age=values(age), bodyType=values(bodyType), height=values(height), photo=values(photo), \
      star=values(star), title=values(title), `description`=values(`description`), fit=values(fit), purchaseSize=values(purchaseSize), usualSize=values(usualSize), \
      recommendStatus=values(recommendStatus), `date`=values(`date`) ;\
      \
      SELECT * FROM `personal_review`;"
    db.executeQueryAsPromise(query, validatedInputs.placeholders)
      .then((queryResults) => {
        res.send(queryResults)
      }).catch((error) => {
        issue = { issue: "There was a problem running your queries", error }
        console.log(issue)
        res.send(issue)
      })
  } else {
    issue = { issue: "There was a problem validating your inputs", validatedInputs }
    console.log(issue)
    res.send(issue)
  }
})

router.post("/addOrUpdateProductReview", function (req, res, next) {
  let { inputs } = req.body;
  let issue = null
  const validatedInputs = validateAndFormatInputs(inputs)
  if (validatedInputs.inputsAreValid) {
    let query = "\
      INSERT INTO `product_review` (`id`, `rating`, `reviewCount`, `percentRecommended`, `fitToSize`, `pageOfReviewId`) VALUES \
      (?,?,?,?,?,?) \
      ON DUPLICATE KEY UPDATE rating=values(rating), reviewCount=values(reviewCount), percentRecommended=values(percentRecommended), fitToSize=values(fitToSize);\
      \
      SELECT * FROM `product_review`;"
    db.executeQueryAsPromise(query, validatedInputs.placeholders)
      .then((queryResults) => {
        res.send(queryResults)
      }).catch((error) => {
        issue = { issue: "There was a problem running your queries", error }
        console.log(issue)
        res.send(issue)
      })
  } else {
    issue = { issue: "There was a problem validating your inputs", validatedInputs }
    console.log(issue)
    res.send(issue)
  }
})


router.post("/addOrUpdateProductInformation", function (req, res, next) {
  let { inputs } = req.body;
  let issue = null
  const validatedInputs = validateAndFormatInputs(inputs)
  if (validatedInputs.inputsAreValid) {
    let query = "\
      INSERT INTO `product_information` (`title`, `popularity`, `reviewCount`, `starRate`, `price`, `alternatePrice`, `size`, `color`) VALUES \
      (?,?,?,?,?,?,?,?) \
      ON DUPLICATE KEY UPDATE popularity=values(popularity), reviewCount=values(reviewCount), starRate=values(starRate), price=values(price), \
      alternatePrice=values(alternatePrice), size=values(size), color=values(color); \
      \
      SELECT * FROM `product_information`;"
    db.executeQueryAsPromise(query, validatedInputs.placeholders)
      .then((queryResults) => {
        res.send(queryResults)
      }).catch((error) => {
        issue = { issue: "There was a problem running your queries", error }
        console.log(issue)
        res.send(issue)
      })
  } else {
    issue = { issue: "There was a problem validating your inputs", validatedInputs }
    console.log(issue)
    res.send(issue)
  }
})

router.post("/addOrUpdateMaterialItem", function (req, res, next) {
  let { inputs } = req.body;
  let issue = null
  const validatedInputs = validateAndFormatInputs(inputs)
  if (validatedInputs.inputsAreValid) {
    let query = "\
      INSERT INTO `material_item` (`id`, `name`, `percent`) VALUES \
      (?,?,?) \
      ON DUPLICATE KEY UPDATE `name`=values(`name`), percent=values(percent); \
      \
      SELECT * FROM `material_item`;"
    db.executeQueryAsPromise(query, validatedInputs.placeholders)
      .then((queryResults) => {
        res.send(queryResults)
      }).catch((error) => {
        issue = { issue: "There was a problem running your queries", error }
        console.log(issue)
        res.send(issue)
      })
  } else {
    issue = { issue: "There was a problem validating your inputs", validatedInputs }
    console.log(issue)
    res.send(issue)
  }
})

router.post("/addOrUpdateProductDetail", function (req, res, next) {
  let { inputs } = req.body;
  let issue = null
  const validatedInputs = validateAndFormatInputs(inputs)
  if (validatedInputs.inputsAreValid) {
    let query = "\
      INSERT INTO `product_detail` (`id`, `styleNumber`, `colorCode`, `description`, `care`, `origin`) VALUES \
      (?,?,?,?,?,?)\
      ON DUPLICATE KEY UPDATE styleNumber=values(styleNumber), colorCode=values(colorCode), `description`=values(`description`), care=values(care), origin=values(origin); \
      \
      SELECT * FROM `product_detail`;"
    db.executeQueryAsPromise(query, validatedInputs.placeholders)
      .then((queryResults) => {
        res.send(queryResults)
      }).catch((error) => {
        issue = { issue: "There was a problem running your queries", error }
        console.log(issue)
        res.send(issue)
      })
  } else {
    issue = { issue: "There was a problem validating your inputs", validatedInputs }
    console.log(issue)
    res.send(issue)
  }
})

router.post("/addOrUpdateShipping", function (req, res, next) {
  let { inputs } = req.body;
  let issue = null
  const validatedInputs = validateAndFormatInputs(inputs)
  if (validatedInputs.inputsAreValid) {
    let query = "\
      INSERT INTO `shipping` (`title`, `description`, `notice`, `shippingMethod`) VALUES \
      (?,?,?,?)\
      ON DUPLICATE KEY UPDATE `description`=values(`description`), notice=values(notice), shippingMethod=values(shippingMethod); \
      \
      SELECT * FROM `shipping`;"
    db.executeQueryAsPromise(query, validatedInputs.placeholders)
      .then((queryResults) => {
        res.send(queryResults)
      }).catch((error) => {
        issue = { issue: "There was a problem running your queries", error }
        console.log(issue)
        res.send(issue)
      })
  } else {
    issue = { issue: "There was a problem validating your inputs", validatedInputs }
    console.log(issue)
    res.send(issue)
  }
})

router.post("/addOrUpdateStorePickup", function (req, res, next) {
  let { inputs } = req.body;
  let issue = null
  const validatedInputs = validateAndFormatInputs(inputs)
  if (validatedInputs.inputsAreValid) {
    let query = "\
      INSERT INTO `store_pickup` (`title`, `description`, `notice`) VALUES \
      (?,?,?)\
      ON DUPLICATE KEY UPDATE `description`=values(`description`), notice=values(notice); \
      \
      SELECT * FROM `store_pickup`;"
    db.executeQueryAsPromise(query, validatedInputs.placeholders)
      .then((queryResults) => {
        res.send(queryResults)
      }).catch((error) => {
        issue = { issue: "There was a problem running your queries", error }
        console.log(issue)
        res.send(issue)
      })
  } else {
    issue = { issue: "There was a problem validating your inputs", validatedInputs }
    console.log(issue)
    res.send(issue)
  }
})

router.post("/addOrUpdateReturn", function (req, res, next) {
  let { inputs } = req.body;
  let issue = null
  const validatedInputs = validateAndFormatInputs(inputs)
  if (validatedInputs.inputsAreValid) {
    let query = "\
      INSERT INTO `return` (`title`, `description`, `returnPolicy`) VALUES \
      (?,?,?)\
      ON DUPLICATE KEY UPDATE `description`=values(`description`), returnPolicy=values(returnPolicy); \
      \
      SELECT * FROM `return`;"
    db.executeQueryAsPromise(query, validatedInputs.placeholders)
      .then((queryResults) => {
        res.send(queryResults)
      }).catch((error) => {
        issue = { issue: "There was a problem running your queries", error }
        console.log(issue)
        res.send(issue)
      })
  } else {
    issue = { issue: "There was a problem validating your inputs", validatedInputs }
    console.log(issue)
    res.send(issue)
  }
})

//************************************ */
//*********RETRIEVE ROUTES************ */
//************************************ */

router.get('/getProductAcquisition/:shippingTitle', (req, res, next) => {
  const inputs = [req.params.shippingTitle]
  const query = "\
    SELECT `return`.title AS 'Return Option for Area', `return`.description AS 'Return Info', `return`.returnPolicy AS 'Return Policy', \
    `store_pickup`.title AS 'Store Pickup Option', `store_pickup`.description AS 'Store Pickup Description', `store_pickup`.notice AS 'Item Availability', \
    `shipping`.title AS 'Shipping Option for Area', `shipping`.description AS 'Shipping Information', `shipping`.notice AS 'Shipping Notice', \
    `shipping`.shippingMethod AS 'Shipping Methods' \
    FROM `return` \
    JOIN `product_acquisition` ON `product_acquisition`.returnTitle = `return`.title \
    JOIN `store_pickup` ON `store_pickup`.title = `product_acquisition`.storePickupTitle \
    JOIN `shipping` ON `shipping`.title = `product_acquisition`.shippingTitle \
    WHERE shippingTitle = ?;"
  db.executeQueryAsPromise(query, inputs)
    .then(results => {
      if (results.length == 0) {
        res.send("No results found")
      } else {
        res.send(results)
      }
    }).catch((error) => {
      issue = { issue: "There was a problem running your queries", error }
      console.log(issue)
      res.send(issue)
    })
})

router.get('/getProductReview/:id', (req, res, next) => {
  const inputs = [req.params.id]
  const query = "\
    SELECT `product_review`.rating AS 'Overall Rating', `product_review`.reviewCount AS 'Reviews', \
    `product_review`.percentRecommended AS 'Customer Percent Recommended', `product_review`.fitToSize AS 'General Fit', \
    `personal_review`.username AS 'Username', `personal_review`.location AS 'Location', `personal_review`.age AS 'Age', \
    `personal_review`.bodyType AS 'Body Type', `personal_review`.height AS 'Height', `personal_review`.photo AS 'Image Link', \
    `personal_review`.date AS 'Date Reviewed', `personal_review`.star AS 'Personal Star Review', `personal_review`.title AS 'Title', \
    `personal_review`.description AS 'Description', `personal_review`.fit AS 'Product Fit', `personal_review`.purchaseSize AS 'Size Purchased', \
    `personal_review`.usualSize AS 'Usual Size', `personal_review`.recommendStatus AS 'Recommendation' \
    FROM `product_review` \
    LEFT OUTER JOIN `page_of_review` ON `page_of_review`.id = `product_review`.pageOfReviewId \
    LEFT OUTER JOIN `personal_review` ON `personal_review`.id = `page_of_review`.personalReviewId \
    WHERE `product_review`.id = ?; "
  db.executeQueryAsPromise(query, inputs)
    .then(results => {
      if (results.length == 0) {
        res.send("No results found")
      } else {
        res.send(results)
      }
    }).catch((error) => {
      issue = { issue: "There was a problem running your queries", error }
      console.log(issue)
      res.send(issue)
    })
})

//************************************ */
//***********UPDATE ROUTES************ */
//************************************ */


router.post("/updateStoreAvailability", function (req, res, next) {
  let { inputs } = req.body;
  let issue = null
  const validatedInputs = validateAndFormatInputs(inputs)
  if (validatedInputs.inputsAreValid) {
    let query = "\
      UPDATE `store_availability` SET availability = ? WHERE city = ?;\
      \
      SELECT * FROM `store_availability`;"
    db.executeQueryAsPromise(query, validatedInputs.placeholders)
      .then((queryResults) => {
        res.send(queryResults)
      }).catch((error) => {
        issue = { issue: "There was a problem running your queries", error }
        console.log(issue)
        res.send(issue)
      })
  } else {
    issue = { issue: "There was a problem validating your inputs", validatedInputs }
    console.log(issue)
    res.send(issue)
  }
})

router.post("/updateProductPhoto", function (req, res, next) {
  let { inputs } = req.body;
  let issue = null
  const validatedInputs = validateAndFormatInputs(inputs)
  if (validatedInputs.inputsAreValid) {
    let query = "\
      UPDATE `product_photo` SET likeCount = ? WHERE id = ?;\
      \
      SELECT * FROM `product_photo`;"
    db.executeQueryAsPromise(query, validatedInputs.placeholders)
      .then((queryResults) => {
        res.send(queryResults)
      }).catch((error) => {
        issue = { issue: "There was a problem running your queries", error }
        console.log(issue)
        res.send(issue)
      })
  } else {
    issue = { issue: "There was a problem validating your inputs", validatedInputs }
    console.log(issue)
    res.send(issue)
  }
})


//************************************ */
//***********DELETE ROUTES*********** */
//************************************ */

router.post("/deleteProductAcquisition", function (req, res, next) {
  let { inputs } = req.body;
  let issue = null
  const validatedInputs = validateAndFormatInputs(inputs)
  if (validatedInputs.inputsAreValid) {
    let query = "\
      DELETE FROM `product_acquisition` WHERE shippingTitle = ?; \
      \
      SELECT * FROM `product_acquisition`;"
    db.executeQueryAsPromise(query, validatedInputs.placeholders)
      .then((queryResults) => {
        res.send(queryResults)
      }).catch((error) => {
        issue = { issue: "There was a problem running your queries", error }
        console.log(issue)
        res.send(issue)
      })
  } else {
    issue = { issue: "There was a problem validating your inputs", validatedInputs }
    console.log(issue)
    res.send(issue)
  }
})

router.post("/deleteMaterial", function (req, res, next) {
  let { inputs } = req.body;
  let issue = null
  const validatedInputs = validateAndFormatInputs(inputs)
  if (validatedInputs.inputsAreValid) {
    let query = "\
      DELETE FROM `material` WHERE id = ?;\
      \
      SELECT * FROM `material`;"
    db.executeQueryAsPromise(query, validatedInputs.placeholders)
      .then((queryResults) => {
        res.send(queryResults)
      }).catch((error) => {
        issue = { issue: "There was a problem running your queries", error }
        console.log(issue)
        res.send(issue)
      })
  } else {
    issue = { issue: "There was a problem validating your inputs", validatedInputs }
    console.log(issue)
    res.send(issue)
  }
})

router.post("/deleteProductReview", function (req, res, next) {
  let { inputs } = req.body;
  let issue = null
  const validatedInputs = validateAndFormatInputs(inputs)
  if (validatedInputs.inputsAreValid) {
    let query = "\
        DELETE FROM `product_review` WHERE percentRecommended < ?;\
        \
        SELECT * FROM `product_review`;"
    db.executeQueryAsPromise(query, validatedInputs.placeholders)
      .then((queryResults) => {
        res.send(queryResults)
      }).catch((error) => {
        issue = { issue: "There was a problem running your queries", error }
        console.log(issue)
        res.send(issue)
      })
  } else {
    issue = { issue: "There was a problem validating your inputs", validatedInputs }
    console.log(issue)
    res.send(issue)
  }
})

router.post("/deleteStoreAvailability", function (req, res, next) {
  let { inputs } = req.body;
  let issue = null
  const validatedInputs = validateAndFormatInputs(inputs)
  if (validatedInputs.inputsAreValid) {
    let query = "\
      DELETE FROM `store_availability` WHERE city = ?;\
      \
      SELECT * FROM `store_availability`;"
    db.executeQueryAsPromise(query, validatedInputs.placeholders)
      .then((queryResults) => {
        res.send(queryResults)
      }).catch((error) => {
        issue = { issue: "There was a problem running your queries", error }
        console.log(issue)
        res.send(issue)
      })
  } else {
    issue = { issue: "There was a problem validating your inputs", validatedInputs }
    console.log(issue)
    res.send(issue)
  }
})

router.post("/deleteProductInformation", function (req, res, next) {
  let { inputs } = req.body;
  let issue = null
  const validatedInputs = validateAndFormatInputs(inputs)
  if (validatedInputs.inputsAreValid) {
    let query = "\
      DELETE FROM `product_information` WHERE title = ?;\
      \
      SELECT * FROM `product_information`;"
    db.executeQueryAsPromise(query, validatedInputs.placeholders)
      .then((queryResults) => {
        res.send(queryResults)
      }).catch((error) => {
        issue = { issue: "There was a problem running your queries", error }
        console.log(issue)
        res.send(issue)
      })
  } else {
    issue = { issue: "There was a problem validating your inputs", validatedInputs }
    console.log(issue)
    res.send(issue)
  }
})

router.post("/deleteProductDetail", function (req, res, next) {
  let { inputs } = req.body;
  let issue = null
  const validatedInputs = validateAndFormatInputs(inputs)
  if (validatedInputs.inputsAreValid) {
    let query = "\
      DELETE FROM `product_detail` WHERE id = ?;\
      \
      SELECT * FROM `product_detail`;"
    db.executeQueryAsPromise(query, validatedInputs.placeholders)
      .then((queryResults) => {
        res.send(queryResults)
      }).catch((error) => {
        issue = { issue: "There was a problem running your queries", error }
        console.log(issue)
        res.send(issue)
      })
  } else {
    issue = { issue: "There was a problem validating your inputs", validatedInputs }
    console.log(issue)
    res.send(issue)
  }
})

router.post("/deleteProductPhoto", function (req, res, next) {
  let { inputs } = req.body;
  let issue = null
  const validatedInputs = validateAndFormatInputs(inputs)
  if (validatedInputs.inputsAreValid) {
    let query = "\
      DELETE FROM `product_photo` WHERE id = ?;\
      \
      SELECT * FROM `product_photo`;"
    db.executeQueryAsPromise(query, validatedInputs.placeholders)
      .then((queryResults) => {
        res.send(queryResults)
      }).catch((error) => {
        issue = { issue: "There was a problem running your queries", error }
        console.log(issue)
        res.send(issue)
      })
  } else {
    issue = { issue: "There was a problem validating your inputs", validatedInputs }
    console.log(issue)
    res.send(issue)
  }
})

//************************************ */
//***********GENERIC ROUTES*********** */
//************************************ */
//These routes take care of any calls you make that are spelled wrong or have the wrong type
//No need to mess with them unless you are an experienced programmer

router.get('/*', (req, res, next) => {
  res.send(`The route you used:${req.originalUrl} was not found. Was it supposed to be a POST?`)
})
router.post('/*', (req, res, next) => {
  res.send(`The route you used:${req.originalUrl} was not found. Was it supposed to be a GET?`)
})


//************************************ */
//***********SUPPORTING CODES********* */
//************************************ */
//This code is used by the routes.
//No need to mess with it unless you are an experienced programmer

function rowsToHtmlTable(results) {
  const tableStyle = '"border:1px solid black;padding:5px"'
  const cellStyle = '"border:1px solid black;padding:5px"'
  const cellStyleFirstRow = '"font-weight:600"'
  const htmlRows = results.map((row, index) => {
    const columns = Object.keys(row).map((columnName) => {
      return { columnName, columnValue: row[columnName] }
    })
    let htmlColumns = null
    if (index == 0) {
      htmlColumns = columns.map((column) => {
        return `<th style=${cellStyleFirstRow}>${column.columnName}</th>`
      })
    } else {
      htmlColumns = columns.map((column) => {
        return `<td style=${cellStyle}>${column.columnValue}</td>`
      })
    }
    return `<tr>${htmlColumns.join("")}</tr>`
  })
  return `<table style=${tableStyle}>${htmlRows.join("")}</table>`
}

function validateAndFormatInputs(inputs) {
  let results = { inputsAreValid: true, validations: [], placeholders: [] }
  if (typeof (inputs) !== "object") {
    results.inputsAreValid = false
    results.validations.push({ error: true, message: `Expecting an object, got: ${typeof (inputs)}` })
  }
  Object.keys(inputs).forEach((input) => {
    let valueOfInput = inputs[input]
    switch (input) {
      //add a case for any input that you want to validate
      case "id":
        if (valueOfInput != null && !Number.isInteger(valueOfInput)) {
          results.inputsAreValid = false
          results.validations.push({ error: true, message: `In id value expecting null or an integer, got: ${valueOfInput}` })
        }
        break
      case "dateAdded":
        if (valueOfInput === "*fillInCurrentDate*") valueOfInput = mysqlTimestamp()
        if (isNaN(Date.parse(valueOfInput))) {
          results.inputsAreValid = false
          results.validations.push({ error: true, message: `This is not a valid date: ${valueOfInput}` })
        }
        break
      case "email":
        if (!valueOfInput.includes("@")) {
          results.inputsAreValid = false
          results.validations.push({ error: true, message: `There needs to be an @ in your email input, got: ${valueOfInput}` })
        }
        break
    }
    results.placeholders.push(valueOfInput)
  })
  return results
}

mysqlTimestamp = () => {
  var date = new Date(Date.now());
  var yyyy = date.getFullYear();
  var mm = date.getMonth() + 1;
  var dd = date.getDate();
  var hh = date.getHours();
  var min = date.getMinutes();
  var ss = date.getSeconds();
  var mysqlDateTime = yyyy + '-' + mm + '-' + dd + ' ' + hh + ':' + min + ':' + ss;
  return mysqlDateTime;
}
module.exports = router;
