-- ****************
-- *    Orders    *
-- ****************

-- A Bar Chart
-- Question: How many orders has each customer (company) made?
-- Query Function Demonstrated: GROUP BY, SELECT, AS, FROM, COUNT(), JOIN
SELECT customers.CompanyName AS "Company Name", COUNT(orders.OrderID) AS "Quantity Bought" 
FROM customers
JOIN  orders ON orders.CustomerID = customers.CustomerID
GROUP BY customers.CompanyName;

-- A time series
-- Question: How does the quantity of product ordered per month change over time?
-- Query Function Demonstrated: DATE_FORMAT(), SUM(), ORDER BY
SELECT date_format(orders.OrderDate, '%Y-%m-%d') AS "Month", SUM(`order details`.Quantity) AS "Quantity of Product Ordered"
FROM orders
JOIN `order details` ON `order details`.OrderID = orders.OrderID
GROUP BY date_format(orders.OrderDate, '%Y-%m')
ORDER BY "Month";


-- Question: Find out the company name and order ID for each order placed, whether or not that order was ever shipped.
-- Query Function Demonstrated: Outer join
SELECT customers.CompanyName AS "Company Name", orders.OrderID AS "Order ID", orders.ShippedDate AS "Shipping Date"
FROM customers
LEFT OUTER JOIN orders ON orders.CustomerID = customers.CustomerID;

-- Question: What products has each company ordered?
-- Query Function Demonstrated: GROUP CONCAT()
SELECT customers.CompanyName AS "Company Name", GROUP_CONCAT(products.ProductName) AS "Products Ordered"
FROM customers
JOIN orders ON orders.CustomerID = customers.CustomerID
JOIN `order details` ON `order details`.OrderID = orders.OrderID
JOIN products ON products.ProductID = `order details`.ProductID
GROUP BY 1;

-- A table with multiple columns
-- Question: Who were the last 10 orders made by, when was the ordering date, product name, and the quantity ordered?
-- Query Function Demonstrated: LIMIT
SELECT customers.CompanyName AS "Company Name", orders.OrderDate AS "Order Date" , 
products.ProductName AS "Product Name", `order details`.quantity AS "Quantity Ordered"
FROM customers
JOIN orders ON orders.CustomerID = customers.CustomerID
JOIN `order details` ON `order details`.OrderID = orders.OrderID
JOIN products ON products.ProductID = `order details`.ProductID
ORDER BY OrderDate DESC
LIMIT 10;

-- Question: Which countries have orders been shipped to?
-- Query Function Demonstrated: DISTINCT
SELECT DISTINCT ShipCountry AS "Countries Shipped To" FROM orders;

-- ****************
-- *   Suppliers  *
-- ****************

-- Geo Plot
-- Question: How many suppliers are in each country?
-- Query Function Demonstrated: Already shown funcitons
SELECT Country, COUNT(SupplierID) AS "Suppliers in Country"
FROM suppliers
GROUP BY Country
ORDER BY 2;

-- ****************
-- *   Employees  *
-- ****************

-- A single Value
-- Question: What is the average salary of the employees?
-- Query Function Demonstrated: CONCAT(), FORMAT(), AVG()
SELECT CONCAT('$', format(AVG(Salary),2)) AS "Average Company Salary"
FROM employees;

-- Question: What information does the database have about employees who make more than the average amount made at the company?
-- Query Function Demonstrated: Star(*), WHERE, Sub Query in WHERE Clause
SELECT * FROM employees 
WHERE Salary > (SELECT AVG(Salary) FROM employees);

-- A table with multiple columns
-- Question: What are the names of the employees who are not the boss?
-- Query Function Demonstrated: Subqury from a FROM clause
SELECT concat(FirstName, " ", LastName) AS "Employee Name", Title AS "Employee Title"
FROM (SELECT * FROM employees WHERE ReportsTo != 'null') as sub;

-- Bar Chart
-- Questions: How many orders has each Sales Representative brought in?
-- Query Function Demonstrated: Nothing not already done
SELECT count(orders.OrderID) AS "Count of Brought in Orders", concat(employees.FirstName, " ", employees.LastName) AS "Employee Name"
FROM orders
JOIN employees ON employees.EmployeeID = orders.EmployeeID
WHERE employees.Title = "Sales Representative"
GROUP BY 2;

-- ****************
-- *   Products   *
-- ****************

-- Scatter Plot
-- Question: What is the relationship between units in stock to units on order?
-- Query Function Demonstrated: Already Shown Functions
SELECT UnitsInStock AS "Quantity in Stock", UnitsOnOrder AS "Quantity on Order"
FROM products
ORDER BY UnitsInStock;

-- Question: What products does Northwind sell with the phrase Sauce in them?
-- Query Function Demonstrated: LIKE
SELECT ProductName AS "Product Name"
FROM products
WHERE ProductName LIKE "%Sauce%";

-- ****************
-- *   Customers  *
-- ****************

-- Bar Graph
-- Question: Which companies have placed orders higher than the average order price, and what was the price?
-- Query Function Demonstrated: Subquery in HAVING clause, HAVING
SELECT customers.CompanyName AS "Company Name", format(AVG((`order details`.Quantity * `order details`.UnitPrice)), 2) AS "Average"
FROM customers
JOIN orders ON orders.CustomerID = customers.CustomerID
JOIN `order details` ON `order details`.OrderID = orders.OrderID
GROUP BY customers.CustomerID
HAVING Average> (SELECT format(AVG((Quantity * UnitPrice)), 2) from `order details`);